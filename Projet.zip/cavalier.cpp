#include "cavalier.h"

namespace LogiqueJeu
{

}