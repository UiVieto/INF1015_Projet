#pragma once
#include <QObject>
#include <QGraphicsScene>
#include <QMainWindow>
#include <QPushButton>
#include <QVBoxLayout>
#include <QGraphicsRectItem>
#include <QGraphicsScene>

class InterfacePiece : public QGraphicsRectItem
{
public:
	InterfacePiece();

protected:
	void mouseReleaseEvent(QGraphicsSceneMouseEvent* evenement) override;
};

class InterfaceEchiquier : public QGraphicsScene
{
public:
	InterfaceEchiquier(QObject* parent = nullptr);
	~InterfaceEchiquier() = default;

	QList<InterfacePiece*> listePieces;
};

class InterfaceGraphique : public QMainWindow
{
	Q_OBJECT

public:
	InterfaceGraphique(QWidget* parent = nullptr);
	~InterfaceGraphique();

private:
	QGraphicsView* vue;
	InterfaceEchiquier* echiquier;
};
