#pragma once
#include <QObject>
#include <QGraphicsScene>
#include <QMainWindow>
#include <QPushButton>
#include <QVBoxLayout>
#include <QGraphicsRectItem>
#include <QGraphicsScene>

#include "echiquier.h"
#include "pieces.h"

class InterfacePiece : public QGraphicsRectItem
{
public:
	InterfacePiece(pair<int, int> position);

protected:
	void mouseReleaseEvent(QGraphicsSceneMouseEvent* evenement) override;

private:
	pair<int, int> positionActuelle_;
};

class InterfaceEchiquier : public QGraphicsScene
{
public:
	InterfaceEchiquier(QObject* parent = nullptr);
	~InterfaceEchiquier() = default;

	QList<InterfacePiece*> listePieces;
};

class InterfaceGraphique : public QMainWindow
{
	Q_OBJECT

public:
	InterfaceGraphique(QWidget* parent = nullptr);
	~InterfaceGraphique();

private:
	QGraphicsView* vue;
	InterfaceEchiquier* echiquier;
};
