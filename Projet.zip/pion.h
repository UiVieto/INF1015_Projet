#pragma once
#include "piece.h"

namespace LogiqueJeu
{

}
