#include "echiquier.h"
#include <cmath>

/*--------------------------------Pieces---------------------------------*/

Roi::Roi(Couleur couleur) {
	couleur_ = couleur;
}

bool Roi::estMouvementPossible(pair<int, int>& positionInitiale, pair<int, int>& nouvellePosition) const {
	return (abs(nouvellePosition.first - positionInitiale.first) <= 1 && 
		    abs(nouvellePosition.second - positionInitiale.second) <= 1);
}

Tour::Tour(Couleur couleur) {
	couleur_ = couleur;
}

bool Tour::estMouvementPossible(pair<int, int>& positionInitiale, pair<int, int>& nouvellePosition) const {
	const int deplacementHorizontal = abs(nouvellePosition.first - positionInitiale.first);
	const int deplacementVertical = abs(nouvellePosition.second - positionInitiale.second);

	return (deplacementHorizontal - deplacementVertical == max(deplacementHorizontal, deplacementVertical));
}

Fou::Fou(Couleur couleur) {
	couleur_ = couleur;
}

bool Fou::estMouvementPossible(pair<int, int>& positionInitiale, pair<int, int>& nouvellePosition) const {
	return ((positionInitiale.first - nouvellePosition.first) == (positionInitiale.second - nouvellePosition.second));
}

/*--------------------------------Echiquier---------------------------------*/

void Echiquier::ajouterPiece(unique_ptr<Piece> piece, pair<int, int> position) {
	//TODO: V�rifier que la pi�ce ajout�e soit dans l'�chiquier.
		grille_[position] = move(piece);
}

void Echiquier::deplacerPiece(pair<int, int>& positionInitiale, pair<int, int>& nouvellePosition) {
	unique_ptr<Piece>& piece = prendrePiece(positionInitiale);

	if (piece->estMouvementPossible(positionInitiale, nouvellePosition)) 
	{
		if (!verifierObstacle(positionInitiale, nouvellePosition))
			grille_[nouvellePosition] = move(piece);
	}
}

unique_ptr<Piece>& Echiquier::prendrePiece(pair<int, int> position) {
	return grille_[position];
}

bool Echiquier::verifierObstacle(pair<int, int>& positionInitiale, pair<int, int>& nouvelleInitiale)
{
	//TODO: V�rifier s'il y aucune pi�ce qui bloque le chemin.
	return false;  
}