#include "vue.h"
#include <Qpen>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <QDebug>

InterfaceEchiquier::InterfaceEchiquier(QObject* parent) : QGraphicsScene(parent)
{
	for (int i = 0; i <= 8; i++) {
		addLine(0, i * 50, 400, i * 50, QPen(Qt::gray));
		addLine(i * 50, 0, i * 50, 400), QPen(Qt::gray);
	}

	for (int i = 0; i < 4; i++) {
		InterfacePiece* piece = new InterfacePiece();
		piece->setPos(i * 50, 0);
		listePieces.append(piece);
		addItem(piece);
	}
}

InterfaceGraphique::InterfaceGraphique(QWidget* parent) : QMainWindow(parent)
{
	setWindowTitle("Jeu d'echec (prototype)");

	vue = new QGraphicsView(this);
	echiquier = new InterfaceEchiquier(vue);

	vue->setScene(echiquier);

	vue->setAlignment(Qt::AlignLeft | Qt::AlignTop);

	vue->centerOn(0, 0);

	vue->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
	vue->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);

	setCentralWidget(vue);
}

InterfaceGraphique::~InterfaceGraphique() {
	qDebug() << "Destruction de l'interface graphique" << Qt::endl;
}

InterfacePiece::InterfacePiece() {
	setRect(0, 0, 50, 50);
	setPen(QPen(Qt::black));
	setBrush(QBrush(Qt::red));

	setFlag(QGraphicsItem::ItemIsMovable);
	setFlag(QGraphicsItem::ItemIsSelectable);
}

void InterfacePiece::mouseReleaseEvent(QGraphicsSceneMouseEvent* evenement) {
	int x = (pos().x() + 25) - ((int(pos().x()) + 25) % 50);
	int y = (pos().y() + 25) - ((int(pos().y()) + 25) % 50);
		
	setPos(x, y);

	QGraphicsRectItem::mouseReleaseEvent(evenement);
}
